Ważne, żeby postman był zainstalowany w wersji standalone, ponieważ tylko w tej wersji jest możliwość autoryzacji bearer token. Najpierw otwieramy projekt ezd-adapter requests i wykonujemy:
	1. create request - należy pamiętać, żeby w żądaniu (body) pole requestorId miało unikalną wartość
	2. send content list - adres bierzemy z odpowiedzi create request z pola attachments.url, w body wybieramy plik ze spisem zdawczo-odbiorczym (przykładowy plik o nazwie spisZO_przyklad.xml umieściłem w załączniku)
	3. send main file - adres bierzemy z odpowiedzi create request z pola mainFileUploadUrl w body wybieramy plik ze danymi wniosku (przykładowy plik o nazwie request_fix.xml umieściłem w załączniku)
	4. mark request as done - w parametr adresu wklejamy wartość pola requestorId z odpowiedzi z create request
	5. możemy wykonać get status - w parametr adresu wklejamy wartość pola requestorId z odpowiedzi z create request, w odpowiedzi powinniśmy otrzymać status IN_PROGRESS

Następnie do wniosku załączymy pliki, które stworza paczkę. W tym celu w portalu archiwisty należy zweryfikować i zaakceptować stworzony w poprzednich krokach wniosek. Następnie przechodzimy do drugiego projektu ezd-adapter archives i wykonujemy:
	1. start sending archives - w żądaniu w pole requestId podajemy requestorId z odpowiedzi create request z poprzedniego projektu
	2. send file - ten krok wykonujemy 3 razy dla każdego adresu z odpowiedzi start sending archives tak, że dla: archiveUploadUrl - wskazujemy plik z archiwum paczki .tar signatureUploadUrl - wskazujemy plik z podpisem .xades hashUploadUrl - wskazujemy plik z sumą kontrolną checksum
	3. mark archive as sent - w parametr adresu wklejamy wartość pola archiveId z odpowiedzi start sending archives
